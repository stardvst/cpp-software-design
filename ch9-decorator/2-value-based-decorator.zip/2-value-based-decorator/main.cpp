#include "conferenceTicket.h"
#include "cppBook.h"
#include "discounted.h"
#include "taxed.h"

#include <iostream>

int main()
{
  Taxed<Discounted<ConferenceTicket>> item{0.15, /*0.2,*/ "Core C++", 499.0};
  const Money priceBook = item.price();
  std::cout << "Item costs " << priceBook << '\n';
}
